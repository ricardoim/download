/*
 * JS backing file to generate breadcrumbs
 * Author: Ricardo Im
 * Date: 19 Sep 2017
 *
 * Input Parameters:
 * 		currentPage: current Page
 * 		startingDepth: First breadcrumb's  depth. Default value = 2
 *
 * Return Value:
 * 		breadcrumbResults: The object to be returned.
 *
 */

use(["/libs/wcm/foundation/components/utils/AuthoringUtils.js"], function (AuthoringUtils) {

    var breadcrumbResults = { items: [] };
    var startingDepth = 2;
    var thisItem = {};
    log.debug("in breadcrumb js");

    try {
        if (this.currentPage) {
            log.debug("currentPage: "+this.currentPage);
            if(this.startingDepth){
                startingDepth = this.startingDepth;
            }
            log.debug("startingDepth: "+this.startingDepth+" and this.currentPage.getDepth():==>["+this.currentPage.getDepth()+"]");
            try{
                if(this.currentPage.getDepth() <= startingDepth){
                    log.debug("Nothing to do. Page depth is less than or equal to starting depth");
                    // nothing to do
                }else{
                    log.debug("Populate breadcrumbs.");

                    for(; startingDepth<this.currentPage.getDepth(); startingDepth++){

                        log.debug("Getting details for depth:==>["+startingDepth+"]");
                        thisItem = {};
                        thisItem.pageTitle = this.currentPage.getAbsoluteParent(startingDepth).getNavigationTitle();
                        if(!thisItem.pageTitle){
                            thisItem.pageTitle = this.currentPage.getAbsoluteParent(startingDepth).getPageTitle();
                        }
                        if(!thisItem.pageTitle){
                            thisItem.pageTitle = this.currentPage.getAbsoluteParent(startingDepth).getTitle();
                        }
                        thisItem.pagePath = this.currentPage.getAbsoluteParent(startingDepth).getPath()+".html";



                        var addUrlToBreadCrumb = true;
                        if (this.prop) {

                            log.debug("urls excluded by author:" +  this.prop.toString());


                            //If properties is a String:
                            if (Object.prototype.toString.call(this.prop)!== '[object JavaArray]')
                                this.prop = [].concat(this.prop);

                            var counter = 0;
                            var jsonPath;
                            var pagePath;
                            this.prop.forEach(function (item) {
                                    jsonPath = JSON.parse(item);
                                    pagePath = jsonPath.excludeUrl + ".html";

                                    if (thisItem.pagePath===pagePath) {
                                        addUrlToBreadCrumb = false;
                                        log.debug("Not added: " + thisItem.pagePath);

                                    }
                                    counter++;
                                }

                            );

                        }


                        if (addUrlToBreadCrumb) {
                            log.debug("Adding breadcrumb with path:==>["+thisItem.pagePath+"]");
                            breadcrumbResults.items.push(thisItem);
                        }
                        else
                            log.debug("NOT Adding breadcrumb with path:==>["+thisItem.pagePath+"]");
                    }
                }

            }catch(e){

                log.error("Failed to get breadcrumb " + e.toString());

            }
        }
    }
    catch (e) {
        log.error("ERROR: " + e.toString());
    }

    return breadcrumbResults;

});